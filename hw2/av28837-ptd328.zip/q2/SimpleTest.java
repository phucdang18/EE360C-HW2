package q2;
import org.junit.Assert;
import org.junit.Test;

public class SimpleTest {

    private static final int OPERATIONS = 120000;

    @Test
    public void testFischer() {
        long start_time = System.nanoTime();
        int result = q2.a.PIncrement.parallelIncrement(0, 8);
        System.out.println(result);
        long end_time = System.nanoTime();
        long time_perf = end_time - start_time;
        System.out.println("Time: " + time_perf);
        // Fischer takes a long time, you could use a small value for test instead
        Assert.assertEquals(result, OPERATIONS);
    }

    @Test
    public void testLamport() {
        long start_time = System.nanoTime();
        int result = q2.b.PIncrement.parallelIncrement(0, 8);
        System.out.println(result);
        long end_time = System.nanoTime();
        long time_perf = end_time - start_time;
        System.out.println("Time: " + time_perf);
        Assert.assertEquals(result, OPERATIONS);
    }

    @Test
    public void testAnderson() {
        long start_time = System.nanoTime();
        int result = q2.c.PIncrement.parallelIncrement(0, 8);
        System.out.println(result);
        long end_time = System.nanoTime();
        long time_perf = end_time - start_time;
        System.out.println("Time: " + time_perf);
        Assert.assertEquals(result, OPERATIONS);
    }

}
